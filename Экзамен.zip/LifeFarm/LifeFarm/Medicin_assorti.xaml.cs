﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LifeFarm
{
    /// <summary>
    /// Логика взаимодействия для Medicin_assorti.xaml
    /// </summary>
    public partial class Medicin_assorti : Window
    {
        LifeFarmEntities db = new LifeFarmEntities();

        public Medicin_assorti()
        {
            InitializeComponent();

            var med1 = (from x in db.Medicines select x).ToArray();
            MedicinesDataGrid.ItemsSource = med1;

            Medicines = new ObservableCollection<Medicines>();
            LoadMedicinesFromDatabase();

            DataContext = this;


        }

        public ObservableCollection<Medicines> Medicines { get; set; }
        public ObservableCollection<Medicines> Cart { get; set; } = new ObservableCollection<Medicines>();

        private void LoadMedicinesFromDatabase()
        {
            try
            {


                    string query = "SELECT MedicineID, MedicineName, Price, StockQuantity FROM Medicines";

                    using (SqlCommand command = new SqlCommand(query))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Medicines medicine = new Medicines
                                {
                                    ID = Convert.ToInt32(reader["ID"]),
                                    Name = reader["Name"].ToString(),
                                    Cost = Convert.ToDecimal(reader["Cost"]),
                                    Count = Convert.ToInt32(reader["Count"])
                                };
                                Medicines.Add(medicine);
                            }
                        }
                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
