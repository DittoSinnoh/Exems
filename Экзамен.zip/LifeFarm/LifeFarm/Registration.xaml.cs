﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LifeFarm
{
    public partial class Registration : Window
    {
        LifeFarmEntities db = new LifeFarmEntities();

        public Registration()
        {
            InitializeComponent();
        }

        private void registration_button_Click(object sender, RoutedEventArgs e)
        {
            var Users1 = new Users();
            try
            {
                if (box_name.Text.Length == 0 || box_last_name.Text.Length == 0 || box_login.Text.Length == 0 || box_number_phone.Text.Length == 0 || box_one_pas.Password.Length == 0)
                {
                    MessageBox.Show("Вы заполнили не все поля", "Не удалось зарегистрировать!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    if (box_one_pas.Password == box_two_pas.Password)
                    {
                        Users1.Name = box_name.Text;
                        Users1.Last_name = box_last_name.Text;
                        Users1.Father_name = box_father_name.Text;
                        Users1.Login = box_login.Text;
                        Users1.Password = box_one_pas.Password;
                        Users1.Phone = box_number_phone.Text;
                        Users1.ID_role = 1;

                        db.Users.Add(Users1);
                        db.SaveChanges();

                        MessageBox.Show("Вы успешно зарегистрированы!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);

                        MainWindow main = new MainWindow();
                        main.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Повторно введённый пароль не соответствует первому", "Не удалось зарегистрировать!", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Произошла ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
