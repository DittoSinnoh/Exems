﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LifeFarm
{
    public partial class MainWindow : Window
    {
        LifeFarmEntities db = new LifeFarmEntities();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Autorization_button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var user = (from x in db.Users where x.Login == Login_box.Text select x).ToArray();
                if (Login_box.Text.Length == 0 || Password_box.Text.Length == 0)
                {
                    MessageBox.Show("Поля Логин и Пароль обязательны для заполнения", "!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    if (Login_box.Text == user[0].Login)
                    {
                        if (Password_box.Text == user[0].Password)
                        {
                            
                            switch (user[0].ID_role)
                            {
                                 case 1:
                                        MessageBox.Show("Добро пожаловать. Вы успешно авторизовались как покупатель " + user[0].Name, "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                                        Medicin_assorti medicines = new Medicin_assorti();
                                        medicines.Show();
                                        break;
                                 case 2:
                                       MessageBox.Show("Добро пожаловать. Вы успешно авторизовались как сотрудник " + user[0].Name, "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                                       break;
                                 case 3:
                                        MessageBox.Show("Добро пожаловать. Вы успешно авторизовались как администратор " + user[0].Name, "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                                        break;
                                 default:
                                        MessageBox.Show("Данные не обнаружены", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                                        break;
                            }

                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Вы ввели неверный пароль", "Не удалось авторизоваться!", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Вы ввели неверный логин или пароль", "Не удалось авторизоваться!", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (SystemException ex)
            {
                MessageBox.Show($"Ошибка системы {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void Registration_button_Click(object sender, RoutedEventArgs e)
        {
            Registration registration = new Registration();
            registration.Show();
            this.Close();
        }
    }
}
